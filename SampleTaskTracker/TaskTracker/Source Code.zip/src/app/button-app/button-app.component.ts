import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-button-app',
  templateUrl: './button-app.component.html',
  styleUrls: ['./button-app.component.css']
})
export class ButtonAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
